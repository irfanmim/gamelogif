/* GAME POLISI69 */

Di dalam folder source code terdapat file polisi.pl, deskripsi.pl , instruksi.pl, mainmenu.txt, mainmenu2.txt, exit.pl .

Untuk menjalankan game ini, file-file yang ada di source code haruslah lengkap. Jika sudah lengkap, buka main.pl di dalam GNU Prolog di Linux atau di Windows. Lalu game siap untuk dimainkan.